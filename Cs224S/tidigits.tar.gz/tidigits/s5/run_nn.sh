#!/bin/bash

# Note: this TIDIGITS setup has not been tuned at all and has some obvious
# deficiencies; this has been created as a starting point for a tutorial.
# We're just using the "adults" data here, not the data from children.

# Kaldi example running script
# Adapted for Stanford's CS 224s: Spoken Language Processing
# Adapted by Peng Qi
# Modified by  Allen Nie & Berk Coker
# Last updated: April 9, 2017

rm -rf exp/nnet
rm -rf tri/aligned

. ./path.sh
. ./cmd.sh

steps/align_si.sh --nj 4 --cmd "$train_cmd" \
   data/train data/lang exp/tri exp/tri/aligned


## ======== Task 5 Neural Network ========
# Tune the following four parameters
num_epochs=8
splice_width=4
num_hidden_layers=1
initial_learning_rate=0.02


num_threads=8
experiment_dir=exp/nnet/
. ./utils/parse_options.sh


mkdir -p $experiment_dir	
steps/nnet2/train_tanh_fast.sh --stage -10 \
  --num-threads "$num_threads" \
  --num-epochs "$num_epochs" \
  --num-epochs-extra 2 \
  --splice-width "$splice_width" \
  --minibatch-size 512 \
  --num-hidden-layers "$num_hidden_layers" \
  --initial-learning-rate "$initial_learning_rate" \
  --final-learning-rate 0.004 \
  --cmd "$decode_cmd" \
  data/train data/lang exp/tri/aligned $experiment_dir || exit 1;


steps/nnet2/decode.sh \
   --num-threads "$num_threads" \
   --nj 8 \
   exp/tri/graph data/train exp/nnet/decode_train || exit 1;

steps/nnet2/decode.sh \
   --num-threads "$num_threads" \
   --nj 8 \
   exp/tri/graph data/test exp/nnet/decode_test || exit 1;

## ====== Task 5 End =======


# Getting results [see RESULTS file]
:echo "=== Word Error Rates ==="
for x in exp/nnet/decode_train*; do [ -d $x ] && grep WER $x/wer_* | utils/best_wer.sh; done
for x in exp/nnet/decode_test*; do [ -d $x ] && grep WER $x/wer_* | utils/best_wer.sh; done
echo "=== Sentence Error Rates ==="
for x in exp/nnet/decode_train*; do [ -d $x ] && grep SER $x/wer_* | utils/best_wer.sh; done
for x in exp/nnet/decode_test*; do [ -d $x ] && grep SER $x/wer_* | utils/best_wer.sh; done


