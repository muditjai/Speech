#!/bin/bash

# Note: this TIDIGITS setup has not been tuned at all and has some obvious
# deficiencies; this has been created as a starting point for a tutorial.
# We're just using the "adults" data here, not the data from children.

# Kaldi example running script
# Adapted for Stanford's CS 224s: Spoken Language Processing
# Adapted by Peng Qi
# Modified by Allen Nie & Berk Coker
# Last updated: April 9, 2017

rm -rf exp/mono/aligned
rm -rf exp/tri

. ./path.sh
. ./cmd.sh

## CS 224S: Task 4 - Improve the triphone acoustic model ======
steps/align_si.sh --nj 4 --cmd "$train_cmd" \
   data/train data/lang exp/mono exp/mono/aligned

steps/train_deltas.sh --cmd "$train_cmd" \
    10 100 data/train data/lang exp/mono/aligned exp/tri

utils/mkgraph.sh data/lang exp/tri exp/tri/graph && \
steps/decode.sh --nj 10 --cmd "$decode_cmd" \
    exp/tri/graph data/test exp/tri/decode
## ======== Task 4 End =======


# Getting results [see RESULTS file]
echo "=== Word Error Rates ==="
for x in exp/tri/decode*; do [ -d $x ] && grep WER $x/wer_* | utils/best_wer.sh; done
echo "=== Sentence Error Rates ==="
for x in exp/tri/decode*; do [ -d $x ] && grep SER $x/wer_* | utils/best_wer.sh; done

#exp/mono/decode/wer_17:%SER 3.67 [ 319 / 8700 ]
#exp/tri/decode/wer_19:%SER 2.64 [ 230 / 8700 ]
