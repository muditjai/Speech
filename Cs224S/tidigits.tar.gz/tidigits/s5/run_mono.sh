#!/bin/bash

# Note: this TIDIGITS setup has not been tuned at all and has some obvious
# deficiencies; this has been created as a starting point for a tutorial.
# We're just using the "adults" data here, not the data from children.

# Kaldi example running script
# Adapted for Stanford's CS 224s: Spoken Language Processing
# Adapted by Peng Qi
# Modified by Allen Nie & Berk Coker
# Last updated: April 9, 2017

rm -rf mfcc
rm -rf data
rm -rf exp

. ./path.sh
. ./cmd.sh

# The following section sets the training data.
tidigits=/afs/ir/class/cs224s/hw/hw2/data/TIDIGITS
traindir=$1
[ -z "$traindir" ] && traindir=1

case $traindir in
1 ) traindir="train_reduced_men"; monodir="train";;
2 ) traindir="train_reduced_women"; monodir="train";;
3 ) traindir="train_reduced"; monodir="train";;
4 ) traindir="train"; monodir="train_1k";;
* ) echo "ERROR: Unknown training directory setting" && exit 1;
esac

# The following command prepares the data/{train,dev,test} directories.
local/tidigits_data_prep.sh $tidigits $traindir || exit 1;
local/tidigits_prepare_lang.sh  || exit 1;
utils/validate_lang.pl data/lang/ # Note; this actually does report errors,
   # and exits with status 1, but we've checked them and seen that they
   # don't matter (this setup doesn't have any disambiguation symbols,
   # and the script doesn't like that).



## CS 224S: Task 2 - Improve Feature Extraction
# Now make MFCC features.
# mfccdir should be some place with a largish disk where you
# want to store MFCC features.
mfccdir=mfcc
for x in test train; do
 steps/make_mfcc.sh --cmd "$train_cmd" --nj 20 \
   data/$x exp/make_mfcc/$x $mfccdir || exit 1;
 steps/compute_cmvn_stats.sh --fake data/$x exp/make_mfcc/$x $mfccdir || exit 1;
done

## ====== Task 2 End =======

[ $traindir -ne "train" ] || utils/subset_data_dir.sh data/train 1000 data/train_1k


## ======= Task 1 - Improve the monophone acoustic model =====

steps/train_mono.sh  --nj 4 --cmd "$train_cmd" \
  data/$monodir data/lang exp/mono

utils/mkgraph.sh data/lang exp/mono exp/mono/graph && \
steps/decode.sh --nj 10 --stage 0 --cmd "$decode_cmd" \
      exp/mono/graph data/test exp/mono/decode

## ======== Task 1 End =======


# Example of looking at the output.
# utils/int2sym.pl -f 2- data/lang/words.txt  exp/tri1/decode/scoring/19.tra | sed "s/ $//" | sort | diff - data/test/text


# Getting results [see RESULTS file]
echo "=== Word Error Rates ==="
for x in exp/mono/decode*; do [ -d $x ] && grep WER $x/wer_* | utils/best_wer.sh; done
echo "=== Sentence Error Rates ==="
for x in exp/mono/decode*; do [ -d $x ] && grep SER $x/wer_* | utils/best_wer.sh; done

#exp/mono/decode/wer_17:%SER 3.67 [ 319 / 8700 ]
#exp/tri/decode/wer_19:%SER 2.64 [ 230 / 8700 ]
